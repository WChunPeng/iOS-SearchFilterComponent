//
//  ViewController.m
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "ViewController.h"
#import "TT_SearchWithFilterView.h"
#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width  //屏幕宽度
#define SCREENHEIGHT [UIScreen mainScreen].bounds.size.height //屏幕高度

@interface ViewController ()<TT_SearchFiltrateViewDelegate,UIGestureRecognizerDelegate>

@property (strong ,nonatomic) TT_SearchWithFilterView * filtrate;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self test];


}

- (IBAction)filtClick:(id)sender {
    __weak __typeof(self) weakSelf = self;
    
    [UIView animateWithDuration:0.6 animations:^{
        weakSelf.filtrate.frame =  CGRectMake(SCREENWIDTH * 0.2, 0, SCREENWIDTH *0.8, SCREENHEIGHT);
    }];

}

- (void)test {
    
    self.filtrate = [[TT_SearchWithFilterView alloc] initWithTitles:@[@"团队通知标签"] items:@[@[@"全部", @"公司制度", @"放假通知", @"行政处罚", @"未签到处理", @"迟到早退处理", @"公司具体规章制度", @"公司具体规章制度完善"]]];
    self.filtrate.frame = CGRectMake(SCREENWIDTH, 0, SCREENWIDTH *0.8, SCREENHEIGHT);
    self.filtrate.delegate = self;
    
    [self.view addSubview:self.filtrate];
    
    UISwipeGestureRecognizer *swipe2 =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
    swipe2.direction =UISwipeGestureRecognizerDirectionRight;
    [self.filtrate addGestureRecognizer:swipe2];
}

//清扫事件
-(void)swipeAction:(UISwipeGestureRecognizer *)swipe
{
    
    __weak __typeof(self) weakSelf = self;
    
    [UIView animateWithDuration:0.6 animations:^{
        weakSelf.filtrate.frame =  CGRectMake(SCREENWIDTH, 0, SCREENWIDTH *0.8, SCREENHEIGHT);
    }];
    
}

#pragma mark - filetrate delegate

- (void)filtrateView:(TT_SearchWithFilterView *)filtrateView didSelectAtIndexPath:(NSIndexPath *)indexPath {
    
    NSLog(@"%@", indexPath);
}

- (void)filtrateView:(TT_SearchWithFilterView *)filtrateView didFinishClickWithDataArray:(NSArray *)dataArray;
{
    NSLog(@"选中了的数据 %@",dataArray);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

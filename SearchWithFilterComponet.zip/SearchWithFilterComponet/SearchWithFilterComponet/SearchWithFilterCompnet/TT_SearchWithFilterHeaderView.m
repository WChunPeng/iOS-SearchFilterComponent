//
//  TT_SearchWithFilterHeaderView.m
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_SearchWithFilterHeaderView.h"

@interface TT_SearchWithFilterHeaderView ()

@property (nonatomic, strong) UILabel * lab_title;
@end
@implementation TT_SearchWithFilterHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.lab_title];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    float width = self.bounds.size.width;
    float height = self.bounds.size.height;
    
    _lab_title.frame = CGRectMake(15, 0, width - 30, height);
}

- (UILabel *)lab_title {
    
    if (!_lab_title) {
        
        _lab_title = [[UILabel alloc] init];
        _lab_title.textColor = [UIColor colorWithRed:145.0/255.0 green:145.0/255.0 blue:145.0/255.0  alpha:1.0];
        _lab_title.font = [UIFont systemFontOfSize:14];
    }
    return _lab_title;
}

- (void)setHeaderTitle:(NSString *)headerTitle {
    
    if (headerTitle.length > 0) {
        
        _lab_title.text = headerTitle;
    }
}


@end

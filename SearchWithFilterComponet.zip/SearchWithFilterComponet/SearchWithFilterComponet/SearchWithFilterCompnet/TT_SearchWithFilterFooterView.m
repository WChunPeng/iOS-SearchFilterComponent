//
//  TT_SearchWithFilterFooterView.m
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_SearchWithFilterFooterView.h"

@interface TT_SearchWithFilterFooterView ()

@property (nonatomic, strong) UILabel * lab_line;
@end
@implementation TT_SearchWithFilterFooterView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.lab_line];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    float width = self.bounds.size.width;
    float height = self.bounds.size.height;
    
    _lab_line.frame = CGRectMake(15, 0, width - 30, height);
}

- (UILabel *)lab_line {
    
    if (!_lab_line) {
        
        _lab_line = [[UILabel alloc] init];
        _lab_line.backgroundColor = [UIColor colorWithRed:230.0/255.0 green:230.0/255.0 blue:230.0/255.0 alpha:1];
    }
    return _lab_line;
}

@end

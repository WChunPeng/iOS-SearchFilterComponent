//
//  TT_SearchWithFilterFooterView.h
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TT_SearchWithFilterFooterView : UICollectionReusableView

@end

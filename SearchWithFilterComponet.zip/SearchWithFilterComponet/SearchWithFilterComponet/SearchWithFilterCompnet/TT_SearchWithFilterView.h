//
//  TT_SearchWithFilterView.h
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TT_SearchFiltrateViewDelegate;

@interface TT_SearchWithFilterView : UIView

@property (nonatomic, weak) id<TT_SearchFiltrateViewDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray<NSString *> *)titles items:(NSArray<NSArray *> *)items;

- (instancetype)initWithTitles:(NSArray<NSString *> *)titles items:(NSArray<NSArray *> *)items;

@end

@protocol TT_SearchFiltrateViewDelegate <NSObject>


@optional

- (void)filtrateView:(TT_SearchWithFilterView *)filtrateView didSelectAtIndexPath:(NSIndexPath *)indexPath;

- (void)filtrateView:(TT_SearchWithFilterView *)filtrateView didFinishClickWithDataArray:(NSArray *)dataArray;

@end

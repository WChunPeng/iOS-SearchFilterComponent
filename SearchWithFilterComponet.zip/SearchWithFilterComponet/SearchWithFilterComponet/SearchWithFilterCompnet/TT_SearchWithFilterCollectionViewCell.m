//
//  TT_SearchWithFilterCollectionViewCell.m
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_SearchWithFilterCollectionViewCell.h"

@interface TT_SearchWithFilterCollectionViewCell ()

@property (nonatomic, strong) UILabel * lab_title;

@end

@implementation TT_SearchWithFilterCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.lab_title];
    }
    return self;
}

#pragma mark - layout subviews

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _lab_title.frame = self.bounds;
}

#pragma mark - config cell

- (void)configCellWithData:(NSDictionary *)dic {
    
    _lab_title.text = dic[@"title"];
    if ([dic[@"isSelected"] boolValue]) {
        
        _lab_title.backgroundColor = [UIColor colorWithRed:210.0/255.0 green:233.0/255.0 blue:255.0/255.0  alpha:1.0];
        _lab_title.textColor = [UIColor colorWithRed:58.0/255.0 green:158.0/255.0 blue:255.0/255.0  alpha:1.0];
    } else {
        
        _lab_title.backgroundColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0  alpha:1.0];
        _lab_title.textColor = [UIColor colorWithRed:52.0/255.0 green:52.0/255.0 blue:52.0/255.0  alpha:1.0];
    }
}

#pragma mark - setter and getter

- (UILabel *)lab_title {
    
    if (!_lab_title) {
        
        _lab_title = [[UILabel alloc] init];
        _lab_title.layer.cornerRadius = 15.0;
        _lab_title.layer.masksToBounds = YES;
        _lab_title.textAlignment = NSTextAlignmentCenter;
        _lab_title.font = [UIFont systemFontOfSize:15];
    }
    return _lab_title;
}



@end

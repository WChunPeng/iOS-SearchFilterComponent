//
//  TT_SearchWithFilterView.m
//  SearchWithFilterComponet
//
//  Created by Dev on 2017/6/26.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_SearchWithFilterView.h"
#import "TT_SearchWithFilterHeaderView.h"
#import "TT_SearchWithFilterFooterView.h"
#import "TT_SearchWithFilterCollectionViewCell.h"
#import "TT_SearchWithFilterLayout.h"
#import "TT_SearchWithFilterHelper.h"

#define Cell_Filtrate              @"Cell_Filtrate"
#define Collection_FiltrateHeader  @"Collection_FiltrateHeader"
#define Collection_FiltrateFooter  @"Collection_FiltrateFooter"
#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width  //屏幕宽度
#define SCREENHEIGHT [UIScreen mainScreen].bounds.size.height //屏幕高度
#define MarginX      10    //item X间隔
#define MarginY      15    //item Y间隔
#define ItemHeight   30    //item 高度
#define ItemWidth    30    //item 追加宽度
@interface TT_SearchWithFilterView () <UICollectionViewDelegate, UICollectionViewDataSource, TT_SearchCollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView * collectionView;
@property (nonatomic, strong) UIButton * resettingButton;
@property (nonatomic, strong) UIButton * confirmButton;
@property (nonatomic, strong) NSArray * titleArr;
@property (nonatomic, strong) NSArray * itemArr;
@property (nonatomic, strong) NSMutableArray * dataArr;
@end
@implementation TT_SearchWithFilterView

- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray<NSString *> *)titles items:(NSArray<NSArray *> *)items {
    
    self = [super initWithFrame:frame];
    
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1];
        
        _titleArr = [NSArray arrayWithArray:titles];
        _itemArr = [NSArray arrayWithArray:items];
        [self loadData];
        [self addSubviews];
    }
    return self;
}

- (instancetype)initWithTitles:(NSArray<NSString *> *)titles items:(NSArray<NSArray *> *)items {
    
    self = [super init];
    
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1];
        
        _titleArr = [NSArray arrayWithArray:titles];
        _itemArr = [NSArray arrayWithArray:items];
        [self loadData];
        [self addSubviews];
    }
    return self;
}

#pragma mark - load data

- (void)loadData {
    
    for (int i = 0; i < _itemArr.count; i++) {
        
        NSMutableArray * array = [[NSMutableArray alloc] init];
        NSArray * arr = _itemArr[i];
        
        for (int j = 0; j < arr.count; j++) {
            
            NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
            [dic setObject:arr[j] forKey:@"title"];
            /*
             默认第一个选中，暂时去掉
             if (j == 0) {
             
             [dic setObject:@YES forKey:@"isSelected"];
             } else {
             
             [dic setObject:@NO forKey:@"isSelected"];
             }
             
             */
            
            [dic setObject:@NO forKey:@"isSelected"];
            
            [array addObject:dic];
        }
        [self.dataArr addObject:array];
    }
}

#pragma mark - add subviews

- (void)addSubviews {
    
    [self addSubview:self.collectionView];
    [self addSubview:self.resettingButton];
    [self addSubview:self.confirmButton];
}

#pragma mark - layout subviews

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _collectionView.frame = CGRectMake(0, 40, self.frame.size.width, self.frame.size.height - 100);
    [_collectionView reloadData];
    
    _resettingButton.frame = CGRectMake(self.frame.size.width *0.1 , _collectionView.frame.origin.y + _collectionView.frame.size.height, self.frame.size.width *0.35, 40);
    _confirmButton.frame = CGRectMake(self.frame.size.width *0.55 ,_collectionView.frame.origin.y + _collectionView.frame.size.height, self.frame.size.width *0.35, 40);
    
}


#pragma mark - collectionView delegate

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return _titleArr.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return [_itemArr[section] count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    TT_SearchWithFilterCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:Cell_Filtrate forIndexPath:indexPath];
    if (indexPath.row < [self.dataArr[indexPath.section] count]) {
        
        NSDictionary * dic = _dataArr[indexPath.section][indexPath.row];
        [cell configCellWithData:dic];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    /*
     多分区
     */
    
    //    NSMutableArray * array = [NSMutableArray arrayWithArray:self.dataArr[indexPath.section]];
    //
    //    for (int i = 0; i < array.count; i++) {
    //
    //        NSMutableDictionary * dic = array[i];
    //        if (i == indexPath.row) {
    //
    //            [dic setObject:@YES forKey:@"isSelected"];
    //        } else {
    //
    //            [dic setObject:@NO forKey:@"isSelected"];
    //        }
    //        [array replaceObjectAtIndex:i withObject:dic];
    //    }
    //    [_dataArr replaceObjectAtIndex:indexPath.section withObject:array];
    //    [_collectionView reloadData];
    //
    //    if (self.delegate && [self.delegate respondsToSelector:@selector(filtrateView:didSelectAtIndexPath:)]) {
    //
    //        [self.delegate filtrateView:self didSelectAtIndexPath:indexPath];
    //    }
    
    /*
     单分区
     */
    
    NSMutableArray * array = [NSMutableArray arrayWithArray:self.dataArr[indexPath.section]];
    
    NSMutableDictionary * dic = array[indexPath.row];
    if ([dic[@"isSelected"] boolValue]) {
        [dic setObject:@NO forKey:@"isSelected"];
    }else{
        [dic setObject:@YES forKey:@"isSelected"];
    }
    
    [array replaceObjectAtIndex:indexPath.row withObject:dic];
    [_dataArr replaceObjectAtIndex:indexPath.section withObject:array];
    [_collectionView reloadData];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(filtrateView:didSelectAtIndexPath:)]) {
        
        [self.delegate filtrateView:self didSelectAtIndexPath:indexPath];
    }
    
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    
    /*
     带分割线
     */
    
    //    if (kind == UICollectionElementKindSectionHeader) {
    //
    //        RHFiltrateHeaderView * headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:Collection_FiltrateHeader forIndexPath:indexPath];
    //        headerView.headerTitle = _titleArr[indexPath.section];
    //        return headerView;
    //    } else {
    //
    //        RHFiltrateFooterView * footerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:Collection_FiltrateFooter forIndexPath:indexPath];
    //        return footerView;
    //    }
    
    
    /*
     不带分割线
     */
    TT_SearchWithFilterHeaderView * headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:Collection_FiltrateHeader forIndexPath:indexPath];
    headerView.headerTitle = _titleArr[indexPath.section];
    return headerView;
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    float width = [TT_SearchWithFilterHelper getWidthByText:_itemArr[indexPath.section][indexPath.row] font:[UIFont systemFontOfSize:15]] + ItemWidth;
    return CGSizeMake(width, 30);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    
    return CGSizeMake(self.bounds.size.width, 40);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section {
    
    return CGSizeMake(self.bounds.size.width, 1);
}

#pragma mark - 按钮点击事件

- (void)resettingClick
{
    [self.dataArr removeAllObjects];
    [self loadData];
    [self.collectionView reloadData];
}

- (void)confirmClick
{
    __weak __typeof(self) weakSelf = self;
    
    [UIView animateWithDuration:0.6 animations:^{
        weakSelf.frame =  CGRectMake(SCREENWIDTH, 0, SCREENWIDTH, SCREENHEIGHT);
    }];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(filtrateView:didFinishClickWithDataArray:)]) {
        
            [self.delegate filtrateView:self didFinishClickWithDataArray:[self getSeletedDataArray]];
    }
}

- (NSArray *)getSeletedDataArray;
{
    NSMutableArray *selectArray = [NSMutableArray array];
    
    for (NSArray *temArray in self.dataArr) {
        for (int j = 0; j < temArray.count; j++) {
            
            NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithDictionary:temArray[j]];
            
            if ([dic[@"isSelected"] boolValue]) {
                [selectArray addObject:dic];
            }
        }
        
    }
    
    return selectArray;
}

#pragma mark - setter and getter

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        
        TT_SearchWithFilterLayout * flowLayout = [[TT_SearchWithFilterLayout alloc] init];
        flowLayout.minimumLineSpacing = MarginY;
        flowLayout.minimumInteritemSpacing = MarginX;
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 15, 15, 15);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
        _collectionView.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.showsVerticalScrollIndicator = NO;
        
        [_collectionView registerClass:[TT_SearchWithFilterCollectionViewCell class] forCellWithReuseIdentifier:Cell_Filtrate];
        [_collectionView registerClass:[TT_SearchWithFilterHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:Collection_FiltrateHeader];
        //        [_collectionView registerClass:[RHFiltrateFooterView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:Collection_FiltrateFooter];
    }
    return _collectionView;
}

- (UIButton *)resettingButton{
    if (!_resettingButton) {
        _resettingButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_resettingButton setTitle:@"重置" forState:UIControlStateNormal];
        [_resettingButton setBackgroundColor:[UIColor colorWithRed:224.0/255.0 green:224.5/255.0 blue:226.0/255.0 alpha:1]];
        [_resettingButton setTitleColor:[UIColor colorWithRed:58.0/255.0 green:158.0/255.0 blue:255.0/255.0  alpha:1.0] forState:UIControlStateNormal];
        _resettingButton.layer.cornerRadius = 20.0;
        _resettingButton.layer.masksToBounds = YES;
        [_resettingButton addTarget:self action:@selector(resettingClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _resettingButton;
}

- (UIButton *)confirmButton{
    if (!_confirmButton) {
        _confirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_confirmButton setTitle:@"确认" forState:UIControlStateNormal];
        [_confirmButton setBackgroundColor:[UIColor colorWithRed:48.0/255.0 green:148.5/255.0 blue:255.0/255.0 alpha:1]];
        [_confirmButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _confirmButton.layer.cornerRadius = 20.0;
        _confirmButton.layer.masksToBounds = YES;
        [_confirmButton addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _confirmButton;
    
}

- (NSMutableArray *)dataArr {
    
    if (!_dataArr) {
        
        _dataArr = [[NSMutableArray alloc] init];
    }
    return _dataArr;
}

@end
